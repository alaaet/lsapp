<footer class="footer mt-auto py-3">
    <div class="container">
      <span class="text-muted">all rights reserved @Alaaet</span>
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\lsapp\resources\views/inc/footer.blade.php ENDPATH**/ ?>